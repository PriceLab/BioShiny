library(DT)

datatable(head(iris),
          rownames = FALSE,
          options = list(
            columnDefs = list(list(className = 'dt-center', targets = 0:4))
            )
          )
