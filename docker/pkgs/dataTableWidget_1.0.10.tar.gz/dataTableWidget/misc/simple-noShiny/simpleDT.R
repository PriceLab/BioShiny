library(DT)
datatable(iris)
